package org.firstinspires.ftc.teamcode;

public class GlobalVariables{

    public static final boolean logging_10435 = true;

}
